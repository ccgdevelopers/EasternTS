package com.example.easternts.Models;

import com.google.gson.annotations.SerializedName;

import java.util.List;


public class MainResponse {

    private static List<MainStickyMenu> mainStickyMenu;
    private String status;
    private String message;

    public MainResponse(List<MainStickyMenu> mainStickyMenu, String status, String message) {
        this.mainStickyMenu = mainStickyMenu;
        this.status = status;
        this.message = message;
    }

    public static List<MainStickyMenu> getMainStickyMenu() {
        return mainStickyMenu;
    }

    public void setMainStickyMenu(List<MainStickyMenu> mainStickyMenu) {
        this.mainStickyMenu = mainStickyMenu;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    //    @SerializedName("main_sticky_menu")
//    private static List<TopModel> mainStickyMenu;
//
//    @SerializedName("status")
//    private String status;
//
//    @SerializedName("message")
//    private String message;
//
//    public MainResponse(List<TopModel> mainStickyMenu, String status, String message) {
//        this.mainStickyMenu = mainStickyMenu;
//        this.status = status;
//        this.message = message;
//    }
//
//    public static List<TopModel> getMainStickyMenu() {
//        return mainStickyMenu;
//    }
//
//    public void setMainStickyMenu(List<TopModel> mainStickyMenu) {
//        this.mainStickyMenu = mainStickyMenu;
//    }
//
//    public String getStatus() {
//        return status;
//    }
//
//    public void setStatus(String status) {
//        this.status = status;
//    }
//
//    public String getMessage() {
//        return message;
//    }
//
//    public void setMessage(String message) {
//        this.message = message;
//    }
//// Getters and setters
}