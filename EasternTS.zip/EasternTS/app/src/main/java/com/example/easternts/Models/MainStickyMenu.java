package com.example.easternts.Models;

import java.util.List;

public class MainStickyMenu {

    private String title;
    private String image;
    private String sortOrder;
    private List<SliderImage> sliderImages;

    public MainStickyMenu(String title, String image, String sortOrder, List<SliderImage> sliderImages) {
        this.title = title;
        this.image = image;
        this.sortOrder = sortOrder;
        this.sliderImages = sliderImages;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    public List<SliderImage> getSliderImages() {
        return sliderImages;
    }

    public void setSliderImages(List<SliderImage> sliderImages) {
        this.sliderImages = sliderImages;
    }
}
