package com.example.easternts;

import java.util.List;
import com.google.gson.annotations.SerializedName;

public class Response{

	@SerializedName("main_sticky_menu")
	private List<MainStickyMenuItem> mainStickyMenu;

	@SerializedName("message")
	private String message;

	@SerializedName("status")
	private String status;

	public List<MainStickyMenuItem> getMainStickyMenu(){
		return mainStickyMenu;
	}

	public String getMessage(){
		return message;
	}

	public String getStatus(){
		return status;
	}
}