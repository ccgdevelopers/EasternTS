package com.example.easternts;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.easternts.Models.TopModel;
//import com.squareup.picasso.Picasso;

import java.util.List;

public class MainMenuItemAdapter extends RecyclerView.Adapter<MainMenuItemAdapter.ViewHolder> {
    private List<TopModel> mainMenuItems;
    private Context context;

    public MainMenuItemAdapter(Context context, List<TopModel> mainMenuItems) {
        this.context = context;
        this.mainMenuItems = mainMenuItems;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_main_menu, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TopModel menuItem = mainMenuItems.get(position);

        holder.titleTextView.setText(menuItem.getTitle());

        // Load image using Picasso (or any other image loading library)
//        Picasso.get().load(menuItem.getImage()).into(holder.imageView);

        // Add click listener if needed
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle item click
            }
        });
    }

    @Override
    public int getItemCount() {
        return mainMenuItems.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView titleTextView;

        ViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            titleTextView = itemView.findViewById(R.id.titleTextView);
        }
    }
}
