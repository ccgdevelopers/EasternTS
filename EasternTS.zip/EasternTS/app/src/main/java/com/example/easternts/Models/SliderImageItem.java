package com.example.easternts.Models;
import com.google.gson.annotations.SerializedName;
public class SliderImageItem {

    @SerializedName("title")
    private String title;

    @SerializedName("image")
    private String image;

    @SerializedName("sort_order")
    private String sortOrder;

    @SerializedName("cta")
    private String cta;

    public SliderImageItem(String title, String image, String sortOrder, String cta) {
        this.title = title;
        this.image = image;
        this.sortOrder = sortOrder;
        this.cta = cta;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    public String getCta() {
        return cta;
    }

    public void setCta(String cta) {
        this.cta = cta;
    }
}
