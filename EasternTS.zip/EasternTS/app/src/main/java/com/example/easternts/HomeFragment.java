package com.example.easternts;

import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.easternts.Models.MainResponse;
import com.example.easternts.Models.MainStickyMenu;
import com.example.easternts.Models.SliderImage;

import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;


public class HomeFragment extends Fragment {

//    private RecyclerView recyclerView;
//    private MainMenuItemAdapter adapter;
//private static final String JSON_FILE_NAME = "top_repository.json";
//    LinearLayout sliderContainer;
//    Response response ;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

//        ViewPager sliderViewPager = view.findViewById(R.id.sliderViewPager);
        TextView textMessage = view.findViewById(R.id.textMessage);
        TextView textStatus = view.findViewById(R.id.textStatus);
        LinearLayout mainLayout = view.findViewById(R.id.mainLayout);

        String jsonString = loadJSONFromAsset("top_repository.json");
// Use Gson to parse the JSON response
        Gson gson = new Gson();
       Response  response = gson.fromJson(jsonString, Response.class);

// Now you can access the parsed data
//        List<MainStickyMenuItem> mainStickyMenu = response.getMainStickyMenu();
//        String message = response.getMessage();
//        String status = response.getStatus();

        Log.d("CTN", "onCreateView: "+ response.getMessage());
        textMessage.setText(response.getMessage());
        textStatus.setText(response.getStatus());

        for (MainStickyMenuItem item : response.getMainStickyMenu()) {
            // Inflate a layout for each MainStickyMenuItem
            View mainItemView = getLayoutInflater().inflate(R.layout.main_sticky_menu_item, mainLayout, false);

            // Find layout elements within each MainStickyMenuItem layout
            ImageView imageMain = mainItemView.findViewById(R.id.imageMain);
            TextView textTitleMain = mainItemView.findViewById(R.id.textTitleMain);
            TextView textSortOrderMain = mainItemView.findViewById(R.id.textSortOrderMain);

            // Set values for MainStickyMenuItem
            Glide.with(requireContext())
                    .load(item.getImage()) // Assuming sliderItem.getImage() returns the URL
                    .placeholder(R.drawable.home) // Placeholder image while loading
                    .error(R.drawable.home) // Image to display in case of an error
                    .into(imageMain);
//            imageMain.setImageURI(Uri.parse(item.getImage())); // Assuming image is a URL
            textTitleMain.setText(item.getTitle());
            textSortOrderMain.setText(item.getSortOrder());

            // Assuming you have a LinearLayout to display SliderImagesItem data
            LinearLayout sliderLayout = mainItemView.findViewById(R.id.sliderLayout);

            // Display SliderImagesItem data within each MainStickyMenuItem
            for (SliderImagesItem sliderItem : item.getSliderImages()) {
                // Inflate a layout for each SliderImagesItem
                View sliderItemView = getLayoutInflater().inflate(R.layout.slider_images_item, sliderLayout, false);

                // Find layout elements within each SliderImagesItem layout
                ImageView imageSlider = sliderItemView.findViewById(R.id.imageSlider);
                TextView textCtaSlider = sliderItemView.findViewById(R.id.textCtaSlider);
                TextView textTitleSlider = sliderItemView.findViewById(R.id.textTitleSlider);
                TextView textSortOrderSlider = sliderItemView.findViewById(R.id.textSortOrderSlider);

                // Set values for SliderImagesItem
                Glide.with(requireContext())
                        .load(sliderItem.getImage()) // Assuming sliderItem.getImage() returns the URL
                        .placeholder(R.drawable.home) // Placeholder image while loading
                        .error(R.drawable.home) // Image to display in case of an error
                        .into(imageSlider);
//                imageSlider.setImageURI(Uri.parse(sliderItem.getImage())); // Assuming image is a URL
                textCtaSlider.setText(sliderItem.getCta());
                textTitleSlider.setText(sliderItem.getTitle());
                textSortOrderSlider.setText(sliderItem.getSortOrder());

                // Add the SliderImagesItem layout to the parent layout
                sliderLayout.addView(sliderItemView);
            }

            // Add the MainStickyMenuItem layout to the parent layout
            mainLayout.addView(mainItemView);
        }
//// Accessing MainStickyMenuItem data
//        for (MainStickyMenuItem item : mainStickyMenu) {
//            String image = item.getImage();
//            String title = item.getTitle();
//            String sortOrder = item.getSortOrder();
//            List<SliderImagesItem> sliderImages = item.getSliderImages();
//
//            // Accessing SliderImagesItem data
//            for (SliderImagesItem sliderItem : sliderImages) {
//                String sliderImage = sliderItem.getImage();
//                String cta = sliderItem.getCta();
//                String sliderTitle = sliderItem.getTitle();
//                String sliderSortOrder = sliderItem.getSortOrder();
//
//                // Now you can use the parsed data as needed
//            }
//        }
//         sliderContainer = view.findViewById(R.id.sliderContainer);

//        String jsonData = loadJSONFromAsset(JSON_FILE_NAME);
//
//        if (jsonData != null) {
//            try {
//                // Convert the JSON string to JSONObject
//                JSONObject jsonObject = new JSONObject(jsonData);
//
//                // Handle the JSON response
//                handleResponse(jsonObject);
//            } catch (JSONException e) {
//                e.printStackTrace();
//                Toast.makeText(getContext(), "Error parsing JSON data", Toast.LENGTH_SHORT).show();
//            }
//        } else {
//            Toast.makeText(getContext(), "Error reading JSON data from assets", Toast.LENGTH_SHORT).show();
//        }
////        try {
////            // Read the JSON data from the assets folder
////            InputStream inputStream = getActivity().getAssets().open("top_repository.json");
////            int size = inputStream.available();
////            byte[] buffer = new byte[size];
////            inputStream.read(buffer);
////            inputStream.close();
////
////            // Convert the byte array to a string
////            String jsonString = new String(buffer, StandardCharsets.UTF_8);
////
////            // Parse the JSON data using Gson
////            Gson gson = new Gson();
////            MainResponse mainResponse = gson.fromJson(jsonString, MainResponse.class);
////
////            // Now you can access the data
////            List<MainStickyMenu> mainStickyMenuList = mainResponse.getMainStickyMenu();
////
////            for (MainStickyMenu menu : mainStickyMenuList) {
////                // Access menu details
////                String menuTitle = menu.getTitle();
////                String menuImage = menu.getImage();
////                String menuSortOrder = menu.getSortOrder();
////
////                // Access slider images for each menu
////                List<SliderImage> sliderImages = menu.getSliderImages();
////                for (SliderImage sliderImage : sliderImages) {
////                    // Access slider image details
////                    String sliderTitle = sliderImage.getTitle();
////                    String sliderImageUrl = sliderImage.getImage();
////                    String sliderSortOrder = sliderImage.getSortOrder();
////                    String sliderCta = sliderImage.getCta();
////                }
////            }
////
////            // Assuming you want to display the slider images of the first menu
////            List<SliderImage> firstMenuSliderImages = mainStickyMenuList.get(0).getSliderImages();
////
////            MenuPagerAdapter menuPagerAdapter = new MenuPagerAdapter(getContext(), firstMenuSliderImages);
////            sliderViewPager.setAdapter(menuPagerAdapter);
////
////        } catch (IOException e) {
////            e.printStackTrace();
////            // Handle the exception appropriately (e.g., log, show a message to the user)
////        }
        return view;
    }

    // Helper method to load JSON from the assets folder
    private String loadJSONFromAsset(String fileName) {
        String json;
        try {
            InputStream inputStream = getActivity().getAssets().open(fileName);
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();
            json = new String(buffer, StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return json;
    }
//    private void handleResponse(JSONObject response) {
//        try {
//            String status = response.getString("status");
//            String message = response.getString("message");
//
//            Log.d("CTN", "status: "+ status);
//            Log.d("CTN", "message: "+ message);
//
//            if ("18".equals(status)) {
//                // Successfully retrieved data, now parse and use it
//                JSONArray mainStickyMenu = response.getJSONArray("main_sticky_menu");
//
//                Log.d("CTN", "handleResponse: "+mainStickyMenu.getString(0));
//                // Iterate through the main_sticky_menu array
//                for (int i = 0; i < mainStickyMenu.length(); i++) {
//                    JSONObject menuItem = mainStickyMenu.getJSONObject(i);
//                    String title = menuItem.getString("title");
//                    String image = menuItem.getString("image");
//                    String short_order = menuItem.getString("sort_order");
//
//
////                    // Create an ImageView dynamically for each mainStickyMenu item
////                    ImageView imageView = new ImageView(getContext());
////                    imageView.setLayoutParams(new LinearLayout.LayoutParams(
////                            LinearLayout.LayoutParams.WRAP_CONTENT,
////                            LinearLayout.LayoutParams.WRAP_CONTENT));
////
////                    // Load the image using Picasso (make sure you have added the Picasso library)
////                    Picasso.get().load(image).into(imageView);
////
////                    // Set an OnClickListener to handle the click event for each mainStickyMenu item
////                    final int finalIndex = i;  // To make 'i' effectively final
////                    imageView.setOnClickListener(new View.OnClickListener() {
////                        @Override
////                        public void onClick(View v) {
////                            // Perform the action you want when a mainStickyMenu item is clicked
////                            // For example, displaying a Toast with the title
////                            Toast.makeText(getContext(), "Main Sticky Menu Clicked: " + title, Toast.LENGTH_SHORT).show();
////                        }
////                    });
////
////                    // Add the ImageView to your layout (sliderContainer)
////                    sliderContainer.addView(imageView);
//
//
//                    // Process other fields or the slider_images array if needed
//                    JSONArray sliderImages = menuItem.getJSONArray("slider_images");
//                    for (int j = 0; j < sliderImages.length(); j++) {
//                        JSONObject sliderItem = sliderImages.getJSONObject(j);
//                        String sliderTitle = sliderItem.getString("title");
//                        String sliderImage = sliderItem.getString("image");
//                        String slider_sort_order = sliderItem.getString("sort_order");
//                        String cta = sliderItem.getString("cta");
//
//                        // Process slider item data as needed
//                    }
//                }
//            } else {
//                // Handle other status codes if needed
//                Toast.makeText(getContext(), "Error: " + message, Toast.LENGTH_SHORT).show();
//            }
//        } catch (JSONException e) {
//            e.printStackTrace();
//            Toast.makeText(getContext(), "Error parsing JSON data", Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    private String loadJSONFromAsset(String fileName) {
//        String json = null;
//        try {
//            InputStream is = requireActivity().getAssets().open(fileName);
//            int size = is.available();
//            byte[] buffer = new byte[size];
//            is.read(buffer);
//            is.close();
//            json = new String(buffer, "UTF-8");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return json;
//    }
}