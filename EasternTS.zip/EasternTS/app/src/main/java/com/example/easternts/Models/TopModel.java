package com.example.easternts.Models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TopModel {
    @SerializedName("title")
    private String title;

    @SerializedName("image")
    private String image;

    @SerializedName("sort_order")
    private String sortOrder;

    @SerializedName("slider_images")
    private List<SliderImageItem> sliderImages;

    public TopModel(String title, String image, String sortOrder, List<SliderImageItem> sliderImages) {
        this.title = title;
        this.image = image;
        this.sortOrder = sortOrder;
        this.sliderImages = sliderImages;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    public List<SliderImageItem> getSliderImages() {
        return sliderImages;
    }

    public void setSliderImages(List<SliderImageItem> sliderImages) {
        this.sliderImages = sliderImages;
    }
}
