package com.example.easternts;

import java.util.List;
import com.google.gson.annotations.SerializedName;

public class MainStickyMenuItem{

	@SerializedName("image")
	private String image;

	@SerializedName("title")
	private String title;

	@SerializedName("sort_order")
	private String sortOrder;

	@SerializedName("slider_images")
	private List<SliderImagesItem> sliderImages;

	public String getImage(){
		return image;
	}

	public String getTitle(){
		return title;
	}

	public String getSortOrder(){
		return sortOrder;
	}

	public List<SliderImagesItem> getSliderImages(){
		return sliderImages;
	}
}