package com.example.easternts;

import android.app.Dialog;
import android.content.Context;
import android.view.Window;

public class CustomProgressDialog extends Dialog {

    public CustomProgressDialog(Context context) {
        super(context);


        requestWindowFeature(Window.FEATURE_NO_TITLE);

        // Inflate the custom layout
        setContentView(R.layout.custom_progress_dialog);

        // Set the dialog background to be transparent if needed
        getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        // Make the dialog non-cancelable
        setCancelable(false);
    }



}

