package com.example.easternts;

import com.google.gson.annotations.SerializedName;

public class SliderImagesItem{

	@SerializedName("image")
	private String image;

	@SerializedName("cta")
	private String cta;

	@SerializedName("title")
	private String title;

	@SerializedName("sort_order")
	private String sortOrder;

	public String getImage(){
		return image;
	}

	public String getCta(){
		return cta;
	}

	public String getTitle(){
		return title;
	}

	public String getSortOrder(){
		return sortOrder;
	}
}