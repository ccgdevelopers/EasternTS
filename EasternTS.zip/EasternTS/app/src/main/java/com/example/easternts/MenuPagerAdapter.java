package com.example.easternts;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;
import com.example.easternts.Models.SliderImage;

import java.util.List;

public class MenuPagerAdapter extends PagerAdapter {

    private final Context context;
    private final List<SliderImage> sliderImages;

    public MenuPagerAdapter(Context context, List<SliderImage> sliderImages) {
        this.context = context;
        this.sliderImages = sliderImages;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.slider_item, container, false);

        ImageView sliderImage = view.findViewById(R.id.sliderImage);
        TextView titleTextView = view.findViewById(R.id.titleTextView);

        // Load slider image using Glide
        Glide.with(context).load(sliderImages.get(position).getImage()).into(sliderImage);

        // Set slider title
        titleTextView.setText(sliderImages.get(position).getTitle());

        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
    }

    @Override
    public int getCount() {
        return sliderImages.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }
}
