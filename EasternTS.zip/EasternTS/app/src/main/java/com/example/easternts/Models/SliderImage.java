package com.example.easternts.Models;

public class SliderImage {

    private String title;
    private String image;
    private String sortOrder;
    private String cta;

    public SliderImage(String title, String image, String sortOrder, String cta) {
        this.title = title;
        this.image = image;
        this.sortOrder = sortOrder;
        this.cta = cta;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    public String getCta() {
        return cta;
    }

    public void setCta(String cta) {
        this.cta = cta;
    }
}
