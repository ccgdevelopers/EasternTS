package com.example.easternts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.viewpager.widget.ViewPager;

import android.content.Context;
import android.content.res.ColorStateList;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    ViewPager mainViewPager;
    TextView page_name;
    TabLayout mainTabLayout;
    CustomProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        progressDialog = new CustomProgressDialog(MainActivity.this);

        mainViewPager = findViewById(R.id.view_pager);
        mainTabLayout = findViewById(R.id.tab_pattern);
        page_name = findViewById(R.id.page_name);

        mainViewPager.setOffscreenPageLimit(5);
        showFragment();
//        new IAmABackgroundTask().execute();
    }

//    class IAmABackgroundTask extends AsyncTask<String, Integer, Boolean> {
//
//
//        @Override
//        protected void onPreExecute() {
//
//
//            progressDialog.show();
//        }
//
//        @Override
//        protected void onPostExecute(Boolean result) {
//            progressDialog.dismiss();
//        }
//
//
//        @Override
//        protected Boolean doInBackground(String... params) {
//
//            runOnUiThread(new Runnable() {
//                public void run() {
//                    showFragment();
//                }
//            });
//            return true;
//        }
//    }

    private void showFragment() {

        ViewPagerSetup(mainViewPager);

        mainTabLayout.setupWithViewPager(mainViewPager);

        Objects.requireNonNull(mainTabLayout.getTabAt(0)).setCustomView(getHeaderView());
        Objects.requireNonNull(mainTabLayout.getTabAt(1)).setCustomView(getHeaderView());
        Objects.requireNonNull(mainTabLayout.getTabAt(2)).setCustomView(getHeaderView());
        Objects.requireNonNull(mainTabLayout.getTabAt(3)).setCustomView(getHeaderView());
        Objects.requireNonNull(mainTabLayout.getTabAt(4)).setCustomView(getHeaderView());
        mainTabLayout.setTabGravity(TabLayout.GRAVITY_FILL);


        for (int i = 0; i < mainTabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = mainTabLayout.getTabAt(i);
            AppCompatTextView appCompatTextView = tab.getCustomView().findViewById(R.id.tbTxt_ccg);
            AppCompatImageView imageView = tab.getCustomView().findViewById(R.id.tbImg_ccg);

            if (i == 0) {
                appCompatTextView.setVisibility(View.VISIBLE);
                appCompatTextView.setTextColor(getResources().getColor(R.color.tab_select));
                imageView.setImageTintList(ColorStateList.valueOf(getResources().getColor(R.color.tab_select)));
                imageView.setImageResource(R.drawable.home);
                appCompatTextView.setText("HOME");

            } else {
                appCompatTextView.setVisibility(View.VISIBLE);
                appCompatTextView.setTextColor(getResources().getColor(R.color.tab_unselect));
                imageView.setImageTintList(ColorStateList.valueOf(getResources().getColor(R.color.tab_unselect)));

                if (i == 1) {
                    imageView.setImageResource(R.drawable.category);
                    appCompatTextView.setText("CATEGORY");
                }
                 if (i == 2) {
                    imageView.setImageResource(R.drawable.curate);
                    appCompatTextView.setText("CURATE");
                }
               if (i == 3) {
                    imageView.setImageResource(R.drawable.sale);
                    appCompatTextView.setText("SALE");
                }
                if (i == 4)  {
                    imageView.setImageResource(R.drawable.more);
                    appCompatTextView.setText("MORE");
                }
            }
        }

        mainTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                AppCompatTextView appCompatTextView = tab.getCustomView().findViewById(R.id.tbTxt_ccg);
                appCompatTextView.setTextColor(getResources().getColor(R.color.tab_select));
                appCompatTextView.setVisibility(View.VISIBLE);

                AppCompatImageView imageView = tab.getCustomView().findViewById(R.id.tbImg_ccg);
                imageView.setImageTintList(ColorStateList.valueOf(getResources().getColor(R.color.tab_select)));


                if (tab.getText().equals("ONE")) {
                    imageView.setImageResource(R.drawable.home);
                    appCompatTextView.setText("HOME");
                    page_name.setText("HOME");
                } else if (tab.getText().equals("TWO")) {
                    imageView.setImageResource(R.drawable.category);
                    appCompatTextView.setText("CATEGORY");
                    page_name.setText("CATEGORY");
                }else if (tab.getText().equals("THREE")) {
                    imageView.setImageResource(R.drawable.curate);
                    appCompatTextView.setText("CURATE");
                    page_name.setText("CURATE");
                }else if (tab.getText().equals("FOUR")) {
                    imageView.setImageResource(R.drawable.sale);
                    appCompatTextView.setText("SALE");
                    page_name.setText("SALE");
                } else {
                    imageView.setImageResource(R.drawable.more);
                    appCompatTextView.setText("MORE");
                    page_name.setText("MORE");
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                AppCompatTextView appCompatTextView = tab.getCustomView().findViewById(R.id.tbTxt_ccg);
                appCompatTextView.setTextColor(getResources().getColor(R.color.tab_unselect));
                appCompatTextView.setVisibility(View.VISIBLE);

                AppCompatImageView imageView = tab.getCustomView().findViewById(R.id.tbImg_ccg);
                imageView.setImageTintList(ColorStateList.valueOf(getResources().getColor(R.color.tab_unselect)));

                if (tab.getText().equals("ONE")) {
                    imageView.setImageResource(R.drawable.home);
                    appCompatTextView.setText("HOME");
                    page_name.setText("HOME");
                } else if (tab.getText().equals("TWO")) {
                    imageView.setImageResource(R.drawable.category);
                    appCompatTextView.setText("CATEGORY");
                    page_name.setText("CATEGORY");
                }else if (tab.getText().equals("THREE")) {
                    imageView.setImageResource(R.drawable.curate);
                    appCompatTextView.setText("CURATE");
                    page_name.setText("CURATE");
                }else if (tab.getText().equals("FOUR")) {
                    imageView.setImageResource(R.drawable.sale);
                    appCompatTextView.setText("SALE");
                    page_name.setText("SALE");
                } else {
                    imageView.setImageResource(R.drawable.more);
                    appCompatTextView.setText("MORE");
                    page_name.setText("MORE");
                }
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

                Log.e("tab", "<--3--->");
            }
        });

    }

    private View getHeaderView() {
        return ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE))
                .inflate(R.layout.layout_tab, null, false);
    }

    private void ViewPagerSetup(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager(), 1);
        adapter.addFragment(new HomeFragment(), "ONE");
        adapter.addFragment(new CategoryFragment(), "TWO");
        adapter.addFragment(new CurateFragment(), "THREE");
        adapter.addFragment(new SaleFragment(), "FOUR");
        adapter.addFragment(new MoreFragment(), "FIVE");
        viewPager.setAdapter(adapter);

    }

    boolean doublePressBack = false;

    @Override
    public void onBackPressed() {
        if (doublePressBack) {
            System.exit(0);
            return;
        }

        doublePressBack = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {

            @Override
            public void run() {
                doublePressBack = false;
            }
        }, 2000);
    }
    }